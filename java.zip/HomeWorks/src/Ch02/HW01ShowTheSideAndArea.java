package Ch02;

public class HW01ShowTheSideAndArea {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x = 12;
		int y = 6;
		System.out.println("Side length : " + 2*(x+y));
		System.out.println("Area : " + x*y);
		
	}

}
