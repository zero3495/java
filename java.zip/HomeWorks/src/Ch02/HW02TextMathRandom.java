package Ch02;

public class HW02TextMathRandom {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println(Math.random());
		System.out.println(Math.random());
		System.out.println(Math.random());
		System.out.println(Math.random());
		System.out.println(Math.random());
		
		
	}
}
