package Ch02;

public class HW03PrintCircleArea {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double r = 10, pi = 3.14;
		System.out.println("The circle area :" + r*r*pi);
	}

}
