package Ch02;

public class HW04PrintCharAsInt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("character '0' as integer : " + (int)'0');
		System.out.println("character 'A' as integer : " + (int)'A');
		System.out.println("character 'a' as integer : " + (int)'a');
		System.out.println("character '張' as integer : " + (int)'張');
		System.out.println("character '君' as integer : " + (int)'君');
		System.out.println("character '雅' as integer : " + (int)'雅');
		
	}

}
