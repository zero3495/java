package Ch02;

public class HW05CalculatTheOrder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double beef = 120;
		double egg = 36;
		double vegetable = 20;
		System.out.println("一斤牛肉 " + beef + "元");
		System.out.println("一斤雞蛋 " + egg + "元");
		System.out.println("一把青菜 " + vegetable + "元");
		System.out.println("一斤半牛肉、兩斤雞蛋、三把青菜，一共 " + (beef*1.5+egg*2+vegetable*3) + "元");
		
	}

}
