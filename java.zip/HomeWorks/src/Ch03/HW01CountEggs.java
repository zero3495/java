package Ch03;

public class HW01CountEggs {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int eggs = 59;
		System.out.println(eggs + "個雞蛋是 " + (eggs / 12) + "打，又 " + (eggs % 12) + "個。");
	}
}
