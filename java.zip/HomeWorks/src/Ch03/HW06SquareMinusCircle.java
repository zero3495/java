package Ch03;

public class HW06SquareMinusCircle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double slenth = 10.0;
		double clenth = 10.0;
		System.out.println(slenth*slenth - (clenth/2)*(clenth/2)*Math.PI);
		
	}

}
