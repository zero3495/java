package Ch03;

public class HW07SystemOutPrintlnDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("5+5 直接輸入");
		System.out.println("5+'5' 直接輸入");
		System.out.println("5+\"5\" 字元\"在System.out.println()中的表示法為\\\"");
	}

}
