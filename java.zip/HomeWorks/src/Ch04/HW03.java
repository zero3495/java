package Ch04;

public class HW03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int pro = 1;
		for (int n = 1; n <= 10; n++) {
			pro *= n;
		}
		System.out.println(pro);
	}

}
