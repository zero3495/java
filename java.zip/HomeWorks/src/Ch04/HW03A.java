package Ch04;

public class HW03A {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int pro = 1;
		int n = 1;
		while(n<=10) {
			pro *= n;
			n++;
		}
		System.out.println(pro);
	}

}
