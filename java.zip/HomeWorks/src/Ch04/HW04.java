package Ch04;

public class HW04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int n = 1; n <= 10; n++) {
			System.out.print(n*n+"  ");
		}
	}

}
