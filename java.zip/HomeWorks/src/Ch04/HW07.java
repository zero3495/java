package Ch04;

public class HW07 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "Hello, World, 大家好";
		for (int n = 0; n < s.length(); n++) {
			System.out.println(s.charAt(n) + "   " + (int) s.charAt(n));
		}
	}
}
