package Ch06.HW09;

public class Animal {

}
