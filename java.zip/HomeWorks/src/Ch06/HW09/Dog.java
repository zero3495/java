package Ch06.HW09;

public class Dog extends Mammal{

}
