package Ch10.HW02;

public class Q10_02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
