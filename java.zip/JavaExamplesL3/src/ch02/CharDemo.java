package ch02;

public class CharDemo {
	public static void main (String[] args) {
		char ch1 = '鄭';
		System.out.println(ch1);
		System.out.println(Integer.toHexString(ch1));
		char ch2 = '\u912d';
		System.out.println(ch2);
		System.out.println(Integer.toHexString(ch2));
		
	}
}
