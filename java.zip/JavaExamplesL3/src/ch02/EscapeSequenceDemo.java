package ch02;

public class EscapeSequenceDemo {
	public static void main(String args[]) {
		char ch1 = '\'';
		System.out.println(ch1);
		
		
		String x = "Hello, World!";
		System.out.println(x);
	}
}
