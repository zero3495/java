package ch03;

public class Assignment01 {
	public static void main(String[] args) {
		int  sum= 0;
		sum  +=  10 ;    //  即 sum = sum + 10;
		System.out.println("1. sum=" + sum);
		sum  +=  20 ;    //  即 sum = sum + 20;
		System.out.println("2. sum=" + sum);
		sum  +=  30 ;    //  即 sum = sum + 30;
		System.out.println("3. sum=" + sum);
		sum  +=  40 ;    //  即 sum = sum + 40;
		System.out.println("4. sum=" + sum);
	}
}
