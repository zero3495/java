package ch03.operator;                           
public class ModulusOperator { 
   public static void main(String agrs[]) {
      int x= 10;
      System.out.println("10 % 3=" + x % 3) ; 
      System.out.println("10 % -3=" + x % -3) ;
      System.out.println("-10 % 3=" + -x % 3) ;
      System.out.println("-10 % -3=" + -x % -3) ;
   }
}
