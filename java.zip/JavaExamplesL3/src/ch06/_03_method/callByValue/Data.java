package ch06._03_method.callByValue;

public class Data {
	int i;
	int j;
	public Data(int i, int j) {
		this.i = i;
		this.j = j;
	}
	public Data() {
		
	}
	
}
