package ch06._03_method.rv2;

public class Cat {

}
