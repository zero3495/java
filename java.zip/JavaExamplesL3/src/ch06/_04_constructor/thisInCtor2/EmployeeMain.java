package ch06._04_constructor.thisInCtor2;

public class EmployeeMain {
	public static void main(String args[]) {
		Employee tom = new Employee("Tom", 45);
		tom.printData();
	}
}
