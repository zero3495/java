package ch06._04_constructor.thisInCtor2;

public class EmployeeOCMain {
	public static void main(String args[]) {
		EmployeeOC tom = new EmployeeOC("Tom", 45);
		tom.printData();
		EmployeeOC Anomerse = new EmployeeOC("Anomerse", 47);
		Anomerse.printData();
	}
}
