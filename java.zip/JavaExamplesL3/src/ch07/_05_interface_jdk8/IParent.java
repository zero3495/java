package ch07._05_interface_jdk8;

public interface IParent {
	public static void staticMethod(){
		System.out.println("這是介面IParent的靜態方法");
	}
}
