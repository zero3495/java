package ch07._05_interface_jdk8;
public interface In_JDK8_2 {
	default public void defaultMethod(){
		System.out.println("這是介面(In_JDK8_2)的Default方法");
	}
}
