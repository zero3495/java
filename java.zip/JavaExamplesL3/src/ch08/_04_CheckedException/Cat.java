package ch08._04_CheckedException;

public class Cat extends Mammal {
	public void smile(){
    	System.out.println("Cat :)");
    }
}
