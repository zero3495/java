package ch08._04_CheckedException;

public class Mammal {
    public void smile(){
    	System.out.println("Mammal :)");
    }
}
