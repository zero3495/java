package ch09._05_Generics._06;

public abstract class Shape {
    public abstract double getArea();
}
