package ch09._09_comparator.v3;

public interface Weight {
    double getWeight();
}
