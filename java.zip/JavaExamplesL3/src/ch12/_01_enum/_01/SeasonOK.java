package ch12._01_enum._01;
//本範例使用最陽春的列舉，此列舉只有四個列舉常數
//沒有任何其他的成員。
public enum SeasonOK {
	SPRING, SUMMER, AUTUMN, WINTER ;
	 
}
