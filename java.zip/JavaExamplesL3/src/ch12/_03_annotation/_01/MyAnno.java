package ch12._03_annotation._01;

public @interface MyAnno {
	String str();
	int val();
}
