package x.appendix.p538;

public class Cat extends Mammal { }
