package x.appendix.p538;

public class Mammal { }
