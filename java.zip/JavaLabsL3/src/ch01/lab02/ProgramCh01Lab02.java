package ch01.lab02;

//練習目的：編寫正確的main()方法

public class  ProgramCh01Lab02 {
     public static void main(String[] args) {
          System.out.println("請更正此程式(Ch01Lab02)含有的錯誤");
     }
}
