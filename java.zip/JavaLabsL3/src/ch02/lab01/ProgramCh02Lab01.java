package ch02.lab01;

//練習目的：了解Java原始程式檔內的最多只能有一個公用類別

public class ProgramCh02Lab01 {
	public static void main(String[] args) {
		System.out.println("請更正此程式(Ch02Lab01)的錯誤");
	}
}
// 下列類別不能與上面的類別同時出現在同一個Java原始程式內
/*
public class AnotherProgram {
	public static void main(String[] args) {
		System.out.println("請更正此程式(Ch02Lab01)的錯誤");
	}
}
*/
