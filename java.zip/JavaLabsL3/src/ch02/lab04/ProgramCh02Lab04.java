package ch02.lab04;

// 練習目的：了解如何定義整數(int)變數

public class ProgramCh02Lab04 {
	public static void main(String[] args) {
		// 定義一個整數(int)型態的變數 i, 初值為 50;
        int i = 50;
		// 定義一個整數(int)型態的變數 n, 初值為 0;
        int n = 0;
	}
}
