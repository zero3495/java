package ch03.lab02;

// 練習目的：練習加法運算，請算出 
// 1 + 3 + 5 + 7 + 9 的總和  

public class ProgramCh03Lab02 {
    public static void main(String[] args) {
    	System.out.println("1 + 3 + 5 + 7 + 9 = " + (1 + 3 + 5 + 7 + 9));
    }
}
