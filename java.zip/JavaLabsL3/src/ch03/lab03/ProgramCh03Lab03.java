package ch03.lab03;
// 請計算 3 + 5 與 3 - 5，並於螢幕上顯示運算結果
// 3 + 5 = (算出的答案)
// 3 - 5  = (算出的答案)

// 練習目的：了解運算的優先順序與字串的加運算

public class ProgramCh03Lab03 {
    public static void main(String[] args) {
        System.out.println("3 + 5 = " + ( 3 + 5 ));
        System.out.println("3 - 5 = " + ( 3 - 5 ));
    }
}
