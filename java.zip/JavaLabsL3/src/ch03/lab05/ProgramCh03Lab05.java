package ch03.lab05;

public class ProgramCh03Lab05 {
/*
 請編寫程式ch03.lab05.ProgramCh03Lab05，在main()之
 內定義某三角形的底(side)與高(height)分別為 10、 5，計算
 此三角形的面積並顯示在螢幕上。
 (三角形的面積為『底』乘上『高』除以2)
*/
	public static void main(String[] args) {
		int side = 10;
		int height = 5;
		int area = side*height/2;
		System.out.println("三角形的面積 : " + area);
	}

}
