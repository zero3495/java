package ch03.lab12;
/*
 在Java中，字元視為整數，我們如何印出某個字元(如字元'1'與字元'李')
 所對應的整數值?
 
請編寫程式ch03.lab12.ProgramCh03Lab12，在main()
之內完成上述的要求。
 
 */
public class ProgramCh03Lab12 {
	public static void main(String[] args) {
		char ch = '李';
		int i = '李';
		System.out.println("字元\'"+ ch +"\'的整數值為: " + i );
		char ch1 = '1';
		int i1 = '1';
		System.out.println("字元\'"+ ch1 +"\'的整數值為: " + i1 );
	}
}
