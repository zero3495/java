package ch03.lab12.solution;
/*
 在Java中，字元視為整數，我們如何印出某個字元(如字元'1'與字元'李')
 所對應的整數值?
 
請編寫程式ch03.lab12.ProgramCh03Lab12，在main()
之內完成上述的要求。
 
 */
public class ProgramCh03Lab12 {
	public static void main(String[] args) {
		int a='1';
		int b='李';
		System.out.println("1=" + a);
		System.out.println("李=" + b);
	}
}
