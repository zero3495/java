package ch06.lab02.solution;

public class Circle {
	public double radius = 10; 

	public double getArea() {
		return radius * radius * Math.PI;
	}

}
