package ch06.lab03;

public class ToyCar {
    int 	speed;
    double	hour;
    public  void getDistance(){
    	System.out.println("此玩具車走了" + speed * hour + "公里");
    }
}
