package ch06.lab04.solution;

public class Foo {
	public void greeting() {
		System.out.println("大家好!");
	}
}
