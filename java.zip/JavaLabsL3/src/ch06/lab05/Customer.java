package ch06.lab05;
/*
 * 請於套件ch06.lab05內，編寫程式Customer.java，
 * 該程式定義 Customer 類別，含有五個屬性與一個方法，
 * 五個屬性如下： 
 1. customerID (int) : 含有初值 12345
 2. name (String)  : 含有初值 張大明
 3. address (String) : 含有初值 台中市大明街581巷415號
 4. phoneNumber (String) : 含有初值 0936666666
 5. emailAddress (String) :含有初值 mmm@sss.com.tw  
 請完成該類別的方法: public void displayInformation()，
 此方法會使用System.out.println();在螢幕上顯示下列Customer的基本資料:
 客戶編號:xxxxxxxx 
 客戶姓名:xxxxxx
 客戶地址:XXXXXXXXXXXXXXXXXXXXXXXX
 電話:xxxxxxxxxxxxxxx
 email:xxxxxxxxxxxxxxxxxxxxxxxx

 完成後，請執行CustomerMain.java來測試你的程式碼。

 */
public class Customer {
	
}
