package ch06.lab05.solution;

public class CustomerMain {	
	public static void main(String[] args) {
        Customer c = new Customer();
        c.displayInformation();
	}
}
