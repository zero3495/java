package ch06.lab06.solution;
/*
//請去除ReturnType.java與ReturnTypeMain.java內的註解，
//修改所有的 ???。

//完成後，請執行ReturnTypeMain.java來測試你的程式碼。
*/
public class ReturnTypeMain {
	public static void main(String[] args) {
		ReturnType rt = new ReturnType();
		System.out.println(rt.m3());
	}
}
