package ch06.lab08;

public class Bar {

	public void greeting(String sa) {
		System.out.println(sa);
	}

}
