package ch06.lab08;

public class BarMain {
	public static void main(String args[]) {
		Bar bar = new Bar();
		bar.greeting("你好嗎?");
		bar.greeting("How are you?");
	}
}
