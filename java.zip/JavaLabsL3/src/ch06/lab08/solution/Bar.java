package ch06.lab08.solution;

public class Bar {
	public void greeting(String message) {
		System.out.println(message);
	}
}
